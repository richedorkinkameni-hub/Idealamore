-- l’idéalAmore : schéma initial Supabase (à appliquer uniquement lorsque le projet backend est créé).
-- IMPORTANT : activer RLS sur chaque table. Ne jamais exposer la clé service_role dans l’application mobile/web.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null check (char_length(display_name) between 1 and 40),
  birth_date date not null,
  city text,
  bio text check (char_length(coalesce(bio, '')) <= 500),
  photo_path text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint profile_adult check (birth_date <= (current_date - interval '18 years')::date)
);

create table if not exists public.likes (
  id bigint generated always as identity primary key,
  from_user uuid not null references public.profiles(id) on delete cascade,
  to_user uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(from_user, to_user),
  check (from_user <> to_user)
);

create table if not exists public.blocks (
  blocker_id uuid not null references public.profiles(id) on delete cascade,
  blocked_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id),
  check (blocker_id <> blocked_id)
);

create table if not exists public.reports (
  id bigint generated always as identity primary key,
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  reported_user_id uuid not null references public.profiles(id) on delete cascade,
  reason text not null check (char_length(reason) between 3 and 1000),
  status text not null default 'pending' check (status in ('pending','reviewing','resolved','dismissed')),
  created_at timestamptz not null default now(),
  check (reporter_id <> reported_user_id)
);

create table if not exists public.matches (
  id bigint generated always as identity primary key,
  user_low uuid not null references public.profiles(id) on delete cascade,
  user_high uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(user_low, user_high),
  check (user_low < user_high)
);

create table if not exists public.messages (
  id bigint generated always as identity primary key,
  match_id bigint not null references public.matches(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 2000),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.likes enable row level security;
alter table public.blocks enable row level security;
alter table public.reports enable row level security;
alter table public.matches enable row level security;
alter table public.messages enable row level security;

-- Policies volontairement non ajoutées ici : elles doivent être conçues et testées avant tout usage réel.
-- Ne pas publier avec des tables RLS activées sans policies adaptées : les accès seront refusés.
-- La validation d’âge ci-dessus est une barrière de données, pas une vérification d’identité.
